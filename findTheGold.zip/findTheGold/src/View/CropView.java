/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;
import model.*;
import control.*;
import java.util.Scanner;
/**
 *
 * @author khaddow
 */
public class CropView {
    // Create a Scanner object
private static Scanner keyboard = new Scanner(System.in);
// Get references to the Game object and the CropData object


}
